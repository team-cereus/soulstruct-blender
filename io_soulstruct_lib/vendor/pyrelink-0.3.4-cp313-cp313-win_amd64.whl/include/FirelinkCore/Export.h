
#ifndef FIRELINK_CORE_API_H
#define FIRELINK_CORE_API_H

#ifdef FIRELINKCORE_STATIC_DEFINE
#  define FIRELINK_CORE_API
#  define FIRELINKCORE_NO_EXPORT
#else
#  ifndef FIRELINK_CORE_API
#    ifdef FirelinkCore_EXPORTS
        /* We are building this library */
#      define FIRELINK_CORE_API 
#    else
        /* We are using this library */
#      define FIRELINK_CORE_API 
#    endif
#  endif

#  ifndef FIRELINKCORE_NO_EXPORT
#    define FIRELINKCORE_NO_EXPORT 
#  endif
#endif

#ifndef FIRELINKCORE_DEPRECATED
#  define FIRELINKCORE_DEPRECATED __declspec(deprecated)
#endif

#ifndef FIRELINKCORE_DEPRECATED_EXPORT
#  define FIRELINKCORE_DEPRECATED_EXPORT FIRELINK_CORE_API FIRELINKCORE_DEPRECATED
#endif

#ifndef FIRELINKCORE_DEPRECATED_NO_EXPORT
#  define FIRELINKCORE_DEPRECATED_NO_EXPORT FIRELINKCORE_NO_EXPORT FIRELINKCORE_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef FIRELINKCORE_NO_DEPRECATED
#    define FIRELINKCORE_NO_DEPRECATED
#  endif
#endif

#endif /* FIRELINK_CORE_API_H */
