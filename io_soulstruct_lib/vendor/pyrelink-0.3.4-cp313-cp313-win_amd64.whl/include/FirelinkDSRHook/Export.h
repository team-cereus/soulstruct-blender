
#ifndef FIRELINK_DSR_HOOK_API_H
#define FIRELINK_DSR_HOOK_API_H

#ifdef FIRELINKDSRHOOK_STATIC_DEFINE
#  define FIRELINK_DSR_HOOK_API
#  define FIRELINKDSRHOOK_NO_EXPORT
#else
#  ifndef FIRELINK_DSR_HOOK_API
#    ifdef FirelinkDSRHook_EXPORTS
        /* We are building this library */
#      define FIRELINK_DSR_HOOK_API 
#    else
        /* We are using this library */
#      define FIRELINK_DSR_HOOK_API 
#    endif
#  endif

#  ifndef FIRELINKDSRHOOK_NO_EXPORT
#    define FIRELINKDSRHOOK_NO_EXPORT 
#  endif
#endif

#ifndef FIRELINKDSRHOOK_DEPRECATED
#  define FIRELINKDSRHOOK_DEPRECATED __declspec(deprecated)
#endif

#ifndef FIRELINKDSRHOOK_DEPRECATED_EXPORT
#  define FIRELINKDSRHOOK_DEPRECATED_EXPORT FIRELINK_DSR_HOOK_API FIRELINKDSRHOOK_DEPRECATED
#endif

#ifndef FIRELINKDSRHOOK_DEPRECATED_NO_EXPORT
#  define FIRELINKDSRHOOK_DEPRECATED_NO_EXPORT FIRELINKDSRHOOK_NO_EXPORT FIRELINKDSRHOOK_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef FIRELINKDSRHOOK_NO_DEPRECATED
#    define FIRELINKDSRHOOK_NO_DEPRECATED
#  endif
#endif

#endif /* FIRELINK_DSR_HOOK_API_H */
