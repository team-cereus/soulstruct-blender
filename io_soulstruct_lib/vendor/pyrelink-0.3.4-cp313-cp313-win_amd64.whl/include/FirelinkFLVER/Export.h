
#ifndef FIRELINK_FLVER_API_H
#define FIRELINK_FLVER_API_H

#ifdef FIRELINKFLVER_STATIC_DEFINE
#  define FIRELINK_FLVER_API
#  define FIRELINKFLVER_NO_EXPORT
#else
#  ifndef FIRELINK_FLVER_API
#    ifdef FirelinkFLVER_EXPORTS
        /* We are building this library */
#      define FIRELINK_FLVER_API 
#    else
        /* We are using this library */
#      define FIRELINK_FLVER_API 
#    endif
#  endif

#  ifndef FIRELINKFLVER_NO_EXPORT
#    define FIRELINKFLVER_NO_EXPORT 
#  endif
#endif

#ifndef FIRELINKFLVER_DEPRECATED
#  define FIRELINKFLVER_DEPRECATED __declspec(deprecated)
#endif

#ifndef FIRELINKFLVER_DEPRECATED_EXPORT
#  define FIRELINKFLVER_DEPRECATED_EXPORT FIRELINK_FLVER_API FIRELINKFLVER_DEPRECATED
#endif

#ifndef FIRELINKFLVER_DEPRECATED_NO_EXPORT
#  define FIRELINKFLVER_DEPRECATED_NO_EXPORT FIRELINKFLVER_NO_EXPORT FIRELINKFLVER_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef FIRELINKFLVER_NO_DEPRECATED
#    define FIRELINKFLVER_NO_DEPRECATED
#  endif
#endif

#endif /* FIRELINK_FLVER_API_H */
