
#ifndef FIRELINK_ER_HOOK_API_H
#define FIRELINK_ER_HOOK_API_H

#ifdef FIRELINKERHOOK_STATIC_DEFINE
#  define FIRELINK_ER_HOOK_API
#  define FIRELINKERHOOK_NO_EXPORT
#else
#  ifndef FIRELINK_ER_HOOK_API
#    ifdef FirelinkERHook_EXPORTS
        /* We are building this library */
#      define FIRELINK_ER_HOOK_API 
#    else
        /* We are using this library */
#      define FIRELINK_ER_HOOK_API 
#    endif
#  endif

#  ifndef FIRELINKERHOOK_NO_EXPORT
#    define FIRELINKERHOOK_NO_EXPORT 
#  endif
#endif

#ifndef FIRELINKERHOOK_DEPRECATED
#  define FIRELINKERHOOK_DEPRECATED __declspec(deprecated)
#endif

#ifndef FIRELINKERHOOK_DEPRECATED_EXPORT
#  define FIRELINKERHOOK_DEPRECATED_EXPORT FIRELINK_ER_HOOK_API FIRELINKERHOOK_DEPRECATED
#endif

#ifndef FIRELINKERHOOK_DEPRECATED_NO_EXPORT
#  define FIRELINKERHOOK_DEPRECATED_NO_EXPORT FIRELINKERHOOK_NO_EXPORT FIRELINKERHOOK_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef FIRELINKERHOOK_NO_DEPRECATED
#    define FIRELINKERHOOK_NO_DEPRECATED
#  endif
#endif

#endif /* FIRELINK_ER_HOOK_API_H */
