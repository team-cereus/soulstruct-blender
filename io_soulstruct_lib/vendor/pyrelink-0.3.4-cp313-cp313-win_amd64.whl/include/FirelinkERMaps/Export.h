
#ifndef FIRELINK_ER_MAPS_API_H
#define FIRELINK_ER_MAPS_API_H

#ifdef FIRELINKERMAPS_STATIC_DEFINE
#  define FIRELINK_ER_MAPS_API
#  define FIRELINKERMAPS_NO_EXPORT
#else
#  ifndef FIRELINK_ER_MAPS_API
#    ifdef FirelinkERMaps_EXPORTS
        /* We are building this library */
#      define FIRELINK_ER_MAPS_API 
#    else
        /* We are using this library */
#      define FIRELINK_ER_MAPS_API 
#    endif
#  endif

#  ifndef FIRELINKERMAPS_NO_EXPORT
#    define FIRELINKERMAPS_NO_EXPORT 
#  endif
#endif

#ifndef FIRELINKERMAPS_DEPRECATED
#  define FIRELINKERMAPS_DEPRECATED __declspec(deprecated)
#endif

#ifndef FIRELINKERMAPS_DEPRECATED_EXPORT
#  define FIRELINKERMAPS_DEPRECATED_EXPORT FIRELINK_ER_MAPS_API FIRELINKERMAPS_DEPRECATED
#endif

#ifndef FIRELINKERMAPS_DEPRECATED_NO_EXPORT
#  define FIRELINKERMAPS_DEPRECATED_NO_EXPORT FIRELINKERMAPS_NO_EXPORT FIRELINKERMAPS_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef FIRELINKERMAPS_NO_DEPRECATED
#    define FIRELINKERMAPS_NO_DEPRECATED
#  endif
#endif

#endif /* FIRELINK_ER_MAPS_API_H */
