#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Firelink::FirelinkCore" for configuration "Release"
set_property(TARGET Firelink::FirelinkCore APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Firelink::FirelinkCore PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/FirelinkCore_static.lib"
  )

list(APPEND _cmake_import_check_targets Firelink::FirelinkCore )
list(APPEND _cmake_import_check_files_for_Firelink::FirelinkCore "${_IMPORT_PREFIX}/lib/FirelinkCore_static.lib" )

# Import target "Firelink::FirelinkFLVER" for configuration "Release"
set_property(TARGET Firelink::FirelinkFLVER APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Firelink::FirelinkFLVER PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/FirelinkFLVER.lib"
  )

list(APPEND _cmake_import_check_targets Firelink::FirelinkFLVER )
list(APPEND _cmake_import_check_files_for_Firelink::FirelinkFLVER "${_IMPORT_PREFIX}/lib/FirelinkFLVER.lib" )

# Import target "Firelink::FirelinkDSRHook" for configuration "Release"
set_property(TARGET Firelink::FirelinkDSRHook APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Firelink::FirelinkDSRHook PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/FirelinkDSRHook.lib"
  )

list(APPEND _cmake_import_check_targets Firelink::FirelinkDSRHook )
list(APPEND _cmake_import_check_files_for_Firelink::FirelinkDSRHook "${_IMPORT_PREFIX}/lib/FirelinkDSRHook.lib" )

# Import target "Firelink::FirelinkERHook" for configuration "Release"
set_property(TARGET Firelink::FirelinkERHook APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Firelink::FirelinkERHook PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/FirelinkERHook_static.lib"
  )

list(APPEND _cmake_import_check_targets Firelink::FirelinkERHook )
list(APPEND _cmake_import_check_files_for_Firelink::FirelinkERHook "${_IMPORT_PREFIX}/lib/FirelinkERHook_static.lib" )

# Import target "Firelink::FirelinkERMaps" for configuration "Release"
set_property(TARGET Firelink::FirelinkERMaps APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Firelink::FirelinkERMaps PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/FirelinkERMaps_static.lib"
  )

list(APPEND _cmake_import_check_targets Firelink::FirelinkERMaps )
list(APPEND _cmake_import_check_files_for_Firelink::FirelinkERMaps "${_IMPORT_PREFIX}/lib/FirelinkERMaps_static.lib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
